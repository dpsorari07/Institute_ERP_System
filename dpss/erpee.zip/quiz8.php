<?php

$testid=$_SESSION['testid'];
$testname=$_SESSION['testname'];

echo"<center><h1>".$testname." (id = ".$testid.") </h1>";
echo"<br><br><br><p>Your Test have been created successfully.</p></center>";

?>
